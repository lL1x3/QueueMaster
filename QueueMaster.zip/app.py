from flask import Flask, render_template, request, redirect, url_for, jsonify, session
from werkzeug.security import check_password_hash, generate_password_hash
from functools import wraps
from database import get_db, init_db
from datetime import datetime, date

app = Flask(__name__)
# Секретный ключ для защиты сессий (обязательно)
app.secret_key = 'super-secret-queue-key-change-me'


# ==================== ДЕКОРАТОРЫ АВТОРИЗАЦИИ ====================

def login_required(role):
    """Декоратор для проверки авторизации (админ или оператор)"""

    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not session.get(f'is_{role}'):
                return redirect(url_for('index'))
            return f(*args, **kwargs)

        return decorated_function

    return decorator


# ==================== АВТОРИЗАЦИЯ API ====================

@app.route('/api/login', methods=['POST'])
def api_login():
    """API для проверки PIN-кода и установки сессии"""
    data = request.get_json()
    role = data.get('role')
    pin = data.get('pin')

    if role not in ('operator', 'admin'):
        return jsonify({'success': False, 'message': 'Неверная роль'})

    conn = get_db()
    row = conn.execute('SELECT value FROM settings WHERE key = ?', (f'{role}_pin',)).fetchone()
    conn.close()

    # Сравниваем введенный PIN с хешем из базы
    if row and check_password_hash(row['value'], pin):
        session[f'is_{role}'] = True
        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'message': '❌ Неверный пароль!'})


@app.route('/logout/<role>')
def logout(role):
    """Выход из системы"""
    session.pop(f'is_{role}', None)
    return redirect(url_for('index'))


# ==================== ГЛАВНАЯ СТРАНИЦА И ТАЛОНЫ ====================

def generate_ticket_number(service_id):
    """Генерация номера талона"""
    conn = get_db()
    prefixes = {1: 'А', 2: 'Б', 3: 'В', 4: 'Г', 5: 'Д', 6: 'Е'}
    prefix = prefixes.get(service_id, 'Z')

    today = date.today().isoformat()
    cursor = conn.execute(
        "SELECT COUNT(*) FROM tickets WHERE service_id = ? AND DATE(created_at) = ?",
        (service_id, today)
    )
    count = cursor.fetchone()[0] + 1
    conn.close()

    return f"{prefix}-{count:03d}"


@app.route('/')
def index():
    conn = get_db()
    services = conn.execute('SELECT * FROM services WHERE is_active = 1').fetchall()

    queue_info = {}
    today = date.today().isoformat()
    for service in services:
        count = conn.execute(
            "SELECT COUNT(*) FROM tickets WHERE service_id = ? AND status = 'waiting' AND DATE(created_at) = ?",
            (service['id'], today)
        ).fetchone()[0]
        queue_info[service['id']] = count

    conn.close()
    return render_template('index.html', services=services, queue_info=queue_info)


@app.route('/get_ticket', methods=['POST'])
def get_ticket():
    service_id = int(request.form['service_id'])
    ticket_number = generate_ticket_number(service_id)

    conn = get_db()
    conn.execute(
        'INSERT INTO tickets (ticket_number, service_id, status) VALUES (?, ?, ?)',
        (ticket_number, service_id, 'waiting')
    )
    conn.commit()

    service = conn.execute('SELECT name FROM services WHERE id = ?', (service_id,)).fetchone()
    today = date.today().isoformat()
    position = conn.execute(
        "SELECT COUNT(*) FROM tickets WHERE service_id = ? AND status = 'waiting' AND DATE(created_at) = ?",
        (service_id, today)
    ).fetchone()[0]

    conn.close()
    return render_template('ticket.html', ticket_number=ticket_number, service_name=service['name'], position=position)


# ==================== ТАБЛО ОЧЕРЕДИ ====================

@app.route('/board')
def board():
    conn = get_db()
    today = date.today().isoformat()

    current = conn.execute('''
        SELECT t.ticket_number, s.name as service_name, o.window_number, o.name as operator_name
        FROM tickets t
        JOIN services s ON t.service_id = s.id
        JOIN operators o ON t.operator_id = o.id
        WHERE t.status = 'serving' AND DATE(t.created_at) = ?
        ORDER BY t.called_at DESC
    ''', (today,)).fetchall()

    waiting = conn.execute('''
        SELECT t.ticket_number, s.name as service_name
        FROM tickets t
        JOIN services s ON t.service_id = s.id
        WHERE t.status = 'waiting' AND DATE(t.created_at) = ?
        ORDER BY t.created_at ASC
        LIMIT 10
    ''', (today,)).fetchall()

    conn.close()
    return render_template('board.html', current=current, waiting=waiting)


# ==================== ПАНЕЛЬ ОПЕРАТОРА ====================

@app.route('/operator')
@login_required('operator')
def operator_list():
    conn = get_db()
    operators = conn.execute('''
        SELECT o.*, s.name as service_name
        FROM operators o
        JOIN services s ON o.service_id = s.id
        WHERE o.is_active = 1
    ''').fetchall()
    conn.close()
    return render_template('operator_list.html', operators=operators)


@app.route('/operator/<int:operator_id>')
@login_required('operator')
def operator_panel(operator_id):
    conn = get_db()
    today = date.today().isoformat()

    operator = conn.execute('SELECT * FROM operators WHERE id = ?', (operator_id,)).fetchone()
    if not operator:
        return "Оператор не найден", 404

    current_ticket = conn.execute('''
        SELECT t.*, s.name as service_name
        FROM tickets t
        JOIN services s ON t.service_id = s.id
        WHERE t.operator_id = ? AND t.status = 'serving' AND DATE(t.created_at) = ?
    ''', (operator_id, today)).fetchone()

    waiting = conn.execute('''
        SELECT t.*, s.name as service_name
        FROM tickets t
        JOIN services s ON t.service_id = s.id
        WHERE t.service_id = ? AND t.status = 'waiting' AND DATE(t.created_at) = ?
        ORDER BY t.created_at ASC
    ''', (operator['service_id'], today)).fetchall()

    stats = conn.execute(
        'SELECT COUNT(*) as total FROM tickets WHERE operator_id = ? AND status = "completed" AND DATE(created_at) = ?',
        (operator_id, today)
    ).fetchone()

    conn.close()
    return render_template('operator.html', operator=operator, current_ticket=current_ticket, waiting=waiting,
                           completed_count=stats['total'] if stats else 0)


@app.route('/operator/<int:operator_id>/next', methods=['POST'])
@login_required('operator')
def call_next(operator_id):
    conn = get_db()
    today = date.today().isoformat()
    operator = conn.execute('SELECT * FROM operators WHERE id = ?', (operator_id,)).fetchone()

    conn.execute('''UPDATE tickets SET status = 'completed', completed_at = ? 
                    WHERE operator_id = ? AND status = 'serving' ''',
                 (datetime.now().isoformat(), operator_id))

    next_ticket = conn.execute('''
        SELECT * FROM tickets WHERE service_id = ? AND status = 'waiting' AND DATE(created_at) = ?
        ORDER BY created_at ASC LIMIT 1
    ''', (operator['service_id'], today)).fetchone()

    if next_ticket:
        conn.execute('''UPDATE tickets SET status = 'serving', called_at = ?, operator_id = ? WHERE id = ?''',
                     (datetime.now().isoformat(), operator_id, next_ticket['id']))

    conn.commit()
    conn.close()
    return redirect(url_for('operator_panel', operator_id=operator_id))


@app.route('/operator/<int:operator_id>/complete', methods=['POST'])
@login_required('operator')
def complete_ticket(operator_id):
    conn = get_db()
    conn.execute('''UPDATE tickets SET status = 'completed', completed_at = ? 
                    WHERE operator_id = ? AND status = 'serving' ''',
                 (datetime.now().isoformat(), operator_id))
    conn.commit()
    conn.close()
    return redirect(url_for('operator_panel', operator_id=operator_id))


@app.route('/operator/<int:operator_id>/skip', methods=['POST'])
@login_required('operator')
def skip_ticket(operator_id):
    conn = get_db()
    conn.execute('''UPDATE tickets SET status = 'skipped', completed_at = ? 
                    WHERE operator_id = ? AND status = 'serving' ''',
                 (datetime.now().isoformat(), operator_id))
    conn.commit()
    conn.close()
    return redirect(url_for('operator_panel', operator_id=operator_id))


# ==================== ПАНЕЛЬ АДМИНИСТРАТОРА ====================

@app.route('/admin')
@login_required('admin')
def admin_panel():
    conn = get_db()
    today = date.today().isoformat()
    services = conn.execute('SELECT * FROM services').fetchall()
    operators = conn.execute('''
        SELECT o.*, s.name as service_name
        FROM operators o LEFT JOIN services s ON o.service_id = s.id
    ''').fetchall()

    stats = conn.execute('''
        SELECT
            COUNT(*) as total,
            SUM(CASE WHEN status = 'waiting' THEN 1 ELSE 0 END) as waiting,
            SUM(CASE WHEN status = 'serving' THEN 1 ELSE 0 END) as serving,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
        FROM tickets WHERE DATE(created_at) = ?
    ''', (today,)).fetchone()

    service_stats = conn.execute('''
        SELECT s.name, COUNT(t.id) as total, SUM(CASE WHEN t.status = 'completed' THEN 1 ELSE 0 END) as completed
        FROM services s
        LEFT JOIN tickets t ON s.id = t.service_id AND DATE(t.created_at) = ?
        GROUP BY s.id
    ''', (today,)).fetchall()

    conn.close()
    return render_template('admin.html', services=services, operators=operators, stats=stats,
                           service_stats=service_stats)


@app.route('/admin/add_service', methods=['POST'])
@login_required('admin')
def add_service():
    name = request.form['name']
    description = request.form.get('description', '')
    avg_time = int(request.form.get('avg_time', 15))

    conn = get_db()
    conn.execute('INSERT INTO services (name, description, avg_time) VALUES (?, ?, ?)', (name, description, avg_time))
    conn.commit()
    conn.close()
    return redirect(url_for('admin_panel'))


@app.route('/admin/delete_service/<int:service_id>', methods=['POST'])
@login_required('admin')
def delete_service(service_id):
    conn = get_db()
    conn.execute('UPDATE services SET is_active = 0 WHERE id = ?', (service_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('admin_panel'))


@app.route('/admin/reset', methods=['POST'])
@login_required('admin')
def reset_queue():
    conn = get_db()
    today = date.today().isoformat()
    conn.execute("DELETE FROM tickets WHERE DATE(created_at) = ?", (today,))
    conn.commit()
    conn.close()
    return redirect(url_for('admin_panel'))


@app.route('/admin/change_operator_pin', methods=['POST'])
@login_required('admin')
def change_operator_pin():
    """Смена пароля операторов"""
    new_pin = request.form.get('new_pin')
    if new_pin and len(new_pin) >= 4:
        hashed_pin = generate_password_hash(new_pin)
        conn = get_db()
        conn.execute('UPDATE settings SET value = ? WHERE key = ?', (hashed_pin, 'operator_pin'))
        conn.commit()
        conn.close()
    return redirect(url_for('admin_panel'))


# ==================== ЗАПУСК ====================

if __name__ == '__main__':
    init_db()
    print("\n" + "=" * 50)
    print("🚀 Система электронной очереди запущена!")
    print("📋 Главная:                 http://localhost:5000")
    print("📋 Страница очереди:        http://localhost:5000/board")
    print("=" * 50 + "\n")
    app.run(debug=True, port=5000)