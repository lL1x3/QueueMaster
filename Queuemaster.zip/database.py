import sqlite3
import os
from datetime import datetime
from werkzeug.security import generate_password_hash

# Вычисляем точный путь к папке, где лежит этот файл
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Приклеиваем к пути имя базы данных
DB_PATH = os.path.join(BASE_DIR, 'queue.db')

def get_db():
    """Создает подключение к БД по абсолютному пути"""
    # Теперь мы используем DB_PATH вместо просто 'queue.db'
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Инициализация базы данных"""
    conn = get_db()
    cursor = conn.cursor()

    # Создание таблиц
    cursor.executescript('''
        -- Таблица услуг
        CREATE TABLE IF NOT EXISTS services (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            avg_time INTEGER DEFAULT 15,
            is_active INTEGER DEFAULT 1
        );

        -- Таблица операторов
        CREATE TABLE IF NOT EXISTS operators (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            window_number INTEGER NOT NULL,
            service_id INTEGER,
            is_active INTEGER DEFAULT 1,
            FOREIGN KEY (service_id) REFERENCES services(id)
        );

        -- Таблица талонов
        CREATE TABLE IF NOT EXISTS tickets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticket_number TEXT NOT NULL,
            service_id INTEGER NOT NULL,
            status TEXT DEFAULT 'waiting',
            created_at TIMESTAMP DEFAULT (DATETIME('now', 'localtime')),
            called_at TIMESTAMP,
            completed_at TIMESTAMP,
            operator_id INTEGER,
            FOREIGN KEY (service_id) REFERENCES services(id),
            FOREIGN KEY (operator_id) REFERENCES operators(id)
        );

        -- Таблица настроек (для хранения зашифрованных паролей)
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
    ''')

    # Инициализация паролей по умолчанию
    cursor.execute('SELECT COUNT(*) FROM settings')
    if cursor.fetchone()[0] == 0:
        print("Добавляем пароли по умолчанию...")
        # Создаем необратимые хеши паролей
        default_operator_hash = generate_password_hash('1234')
        default_admin_hash = generate_password_hash('1423')

        cursor.executemany(
            'INSERT INTO settings (key, value) VALUES (?, ?)',
            [
                ('operator_pin', default_operator_hash),
                ('admin_pin', default_admin_hash)
            ]
        )

    # Проверяем, есть ли тестовые данные
    cursor.execute('SELECT COUNT(*) FROM services')
    if cursor.fetchone()[0] == 0:
        print("Добавляем тестовые услуги...")
        cursor.executemany(
            'INSERT INTO services (name, description, avg_time) VALUES (?, ?, ?)',
            [
                ('Приём документов', 'Приём и регистрация документов', 15),
                ('Выдача справок', 'Выдача готовых справок и документов', 10),
                ('Консультация', 'Консультация по вопросам', 20),
                ('Оплата госпошлин', 'Оплата государственных пошлин', 10),
            ]
        )

    cursor.execute('SELECT COUNT(*) FROM operators')
    if cursor.fetchone()[0] == 0:
        print("Добавляем тестовых операторов...")
        cursor.executemany(
            'INSERT INTO operators (name, window_number, service_id) VALUES (?, ?, ?)',
            [
                ('Иванова Анна Сергеевна', 1, 1),
                ('Петров Борис Владимирович', 2, 2),
                ('Сидорова Мария Константиновна', 3, 3),
                ('Козлов Дмитрий Александрович', 4, 4),
            ]
        )

    conn.commit()
    conn.close()
    print("✅ База данных успешно создана!")


if __name__ == '__main__':
    init_db()